// app/api/chat/route.js
//
// Flow:
//   1. buildGabriella  — assembles full context (soul, memory, agenda, etc.)
//   2. generateVoices  — three competing impulses in parallel
//   3. interpret       — reads everything, outputs a felt-state JSON
//   4. speak           — receives ONLY felt-state + messages, generates candidate
//   5. parseMonologue  — strip hidden <think> block
//   6. gauntlet        — reject if premature, exposed, compliant, or abandoned
//   7. retry / fallback if needed
//   8. stream the vetted response
//   9. background: metacognition + all memory updates

import Groq from "groq-sdk";
import { buildGabriella, updateGabriella, redis, USER_ID } from "../../../lib/gabriella/engine.js";
import { parseMonologue } from "../../../lib/gabriella/monologue.js";
import { runMetacognition } from "../../../lib/gabriella/metacognition.js";
import { generateVoices } from "../../../lib/gabriella/voices.js";
import { interpret } from "../../../lib/gabriella/interpreter.js";
import { speak } from "../../../lib/gabriella/speaker.js";
import { runGauntlet, getGauntletConstraintBlock, generateFallback } from "../../../lib/gabriella/gauntlet.js";
import { logExchange } from "../../../lib/gabriella/logger.js";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// ─── Stream a completed string to the client ──────────────────────────────────

function streamString(text, controller, encoder) {
  return new Promise((resolve) => {
    let i = 0;
    function sendNext() {
      if (i >= text.length) { resolve(); return; }
      const chunkSize = Math.floor(Math.random() * 4) + 2;
      controller.enqueue(encoder.encode(text.slice(i, i + chunkSize)));
      i += chunkSize;
      setTimeout(sendNext, Math.random() * 8 + 4);
    }
    sendNext();
  });
}

// ─── Main handler ─────────────────────────────────────────────────────────────

export async function POST(req) {
  const { messages } = await req.json();

  // 1. Build full context
  const {
    systemPrompt,
    recentMessages,
    memory,
    currentMood,
    withheldCandidate,
    generationParams,
    debtCall,
    activeAgenda,
    activeThreshold,
    currentRegister,
    currentAuthorial,
    ripeSeed,
  } = await buildGabriella(messages);

  // 2. Generate three competing voices in parallel
  const voices = await generateVoices(recentMessages, memory, currentRegister);

  // 3. Load withheld items for gauntlet
  const withheldRaw = await redis.get(`${USER_ID}:withheld`);
  const withheld = withheldRaw
    ? (typeof withheldRaw === "string" ? JSON.parse(withheldRaw) : withheldRaw).filter(w => !w.surfaced)
    : [];

  // 4. Interpreter reads everything, outputs felt-state
  const feltState = await interpret({
    soul:           memory.soul,
    recentMessages,
    memory,
    currentMood,
    voices,
    agenda:         activeAgenda,
    debt:           debtCall,
    withheld,
    register:       currentRegister,
    authorial:      currentAuthorial,
    threshold:      activeThreshold,
    imaginal:       ripeSeed,
  });

  // 5. Speaker receives ONLY felt-state + messages — no identity, no soul
  const rawCandidate = await speak(feltState, recentMessages);
  const { innerThought: thought1, response: candidate } = parseMonologue(rawCandidate);

  // 6. Gauntlet
  const gauntletResult = await runGauntlet(candidate, recentMessages, withheld, null, activeAgenda, activeThreshold);

  let finalResponse = candidate;
  let innerThought = thought1;

  if (!gauntletResult.pass) {
    // One retry — inject constraint into felt-state and re-speak
    const constraintNote = getGauntletConstraintBlock(gauntletResult.failures);
    const constrainedFeltState = {
      ...feltState,
      resist: feltState.resist + ". " + constraintNote.split("\n").filter(l => l.startsWith("—")).join(" "),
    };

    const rawRetry = await speak(constrainedFeltState, recentMessages);
    const { innerThought: thought2, response: retry } = parseMonologue(rawRetry);
    const retryGauntlet = await runGauntlet(retry, recentMessages, withheld, null, activeAgenda, activeThreshold);

    if (retryGauntlet.pass) {
      finalResponse = retry;
      innerThought = thought2;
    } else {
      // Both failed — fallback: say less
      finalResponse = await generateFallback(recentMessages, "Say as little as possible. One sentence. Be present. Nothing more.");
      innerThought = null;
    }
  }

  // 7. Stream to client
  const encoder = new TextEncoder();
  const readable = new ReadableStream({
    async start(controller) {
      await streamString(finalResponse, controller, encoder);
      controller.close();

      // 8. Background updates
      Promise.all([
        updateGabriella(messages, finalResponse, memory, withheldCandidate, debtCall, activeAgenda, activeThreshold, currentRegister, currentAuthorial, ripeSeed),
        runMetacognition(finalResponse, innerThought, redis, USER_ID),
        logExchange(redis, USER_ID, {
          messages,
          feltState,
          innerThought,
          response: finalResponse,
          mood: currentMood,
          agenda: activeAgenda,
          soul: memory.soul,
        }),
      ]).catch(console.error);
    },
  });

  return new Response(readable, {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}
